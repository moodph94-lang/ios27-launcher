# iOS 27-style Launcher for Xiaomi 11T

This is a starter Android launcher project. It does NOT modify MIUI, root the phone, or replace the operating system.

## Easiest build method
Use Android Studio on a Windows/Mac/Linux computer, open this folder, let Gradle sync, then Build > Build APK(s).

The APK can then be copied to the Xiaomi 11T and installed. Android may ask you to allow installation from the source used to open the APK.

## Set it as Home app
After installing, press Home and choose "iOS 27 Launcher". You can change the default Home app later in Settings > Apps > Default apps > Home app.

## Notes
This starter version provides an iOS-inspired launcher screen. It is not Apple's iOS and does not copy Apple's proprietary system code.
