package com.example.ios27launcher;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
 String[] names={"Phone","Messages","Camera","Photos","Music","Maps","Weather","Clock","Settings","Chrome","YouTube","Files","Calendar","Notes","Mail","Calculator"};
 int[] icons={0x260E,0x1F4AC,0x25C9,0x25C9,0x266B,0x2316,0x2601,0x23F0,0x2699,0x25C9,0x25B6,0x1F4C1,0x1F4C5,0x1F4DD,0x2709,0x1F522};
 public void onCreate(Bundle b){super.onCreate(b); setContentView(R.layout.activity_main);
  GridLayout g=findViewById(R.id.grid);
  for(int i=0;i<names.length;i++){ TextView v=new TextView(this); v.setText(new String(Character.toChars(icons[i]))+"\n"+names[i]); v.setTextColor(Color.WHITE); v.setTextSize(13); v.setGravity(17); v.setPadding(4,8,4,8);
   GridLayout.LayoutParams p=new GridLayout.LayoutParams(); p.width=0;p.height=0;p.columnSpec=GridLayout.spec(i%4,1,1f);p.rowSpec=GridLayout.spec(i/4,1,1f);g.addView(v,p);
   final String n=names[i]; v.setOnClickListener(x->{try{Intent in=getPackageManager().getLaunchIntentForPackage(packageFor(n)); if(in!=null)startActivity(in); else Toast.makeText(this,n+" app not found",Toast.LENGTH_SHORT).show();}catch(Exception e){}});}
  updateTime(); new Handler().postDelayed(new Runnable(){public void run(){updateTime();}},60000);
 }
 void updateTime(){TextView t=findViewById(R.id.time);t.setText(new SimpleDateFormat("h:mm",Locale.getDefault()).format(new Date()));}
 String packageFor(String n){if(n.equals("Chrome"))return "com.android.chrome";if(n.equals("YouTube"))return "com.google.android.youtube";if(n.equals("Maps"))return "com.google.android.apps.maps";if(n.equals("Camera"))return "com.android.camera";if(n.equals("Settings"))return "com.android.settings";return "";}
}
